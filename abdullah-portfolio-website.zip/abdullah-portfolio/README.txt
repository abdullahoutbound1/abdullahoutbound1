ABDULLAH PORTFOLIO WEBSITE

Files:
- index.html: responsive one-page portfolio website

Preview:
Open index.html in any modern browser.

Publish free with GitHub Pages:
1. Open https://github.com/abdullahoutbound1/abdullahoutbound1
2. Click Add file > Upload files.
3. Upload index.html to the repository root (same level as README.md).
4. Commit changes.
5. Open Settings > Pages.
6. Under Build and deployment, select Deploy from a branch.
7. Select branch main and folder /(root), then Save.
8. Wait for GitHub Pages to publish. The expected URL is https://abdullahoutbound1.github.io/abdullahoutbound1/ .

Before publishing, review the contact details and service claims in index.html.
